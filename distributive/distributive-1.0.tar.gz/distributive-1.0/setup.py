from distutils.core import setup
setup(name='distributive',
      version='1.0',
      packages = ['spampkg'],
      scripts = ['main.py'])